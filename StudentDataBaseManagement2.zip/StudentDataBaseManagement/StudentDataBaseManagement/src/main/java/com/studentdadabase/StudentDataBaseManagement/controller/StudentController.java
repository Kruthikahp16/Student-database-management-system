package com.studentdadabase.StudentDataBaseManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.studentdadabase.StudentDataBaseManagement.dto.StudentRequest;
import com.studentdadabase.StudentDataBaseManagement.dto.StudentResponse;
import com.studentdadabase.StudentDataBaseManagement.entity.Student;
import com.studentdadabase.StudentDataBaseManagement.service.StudentService;
import com.studnetdatabase.StudentDataBaseManagement.utilll.ResponseStructure;

@RestController
@RequestMapping("/students")
public class StudentController {

	@Autowired
	private StudentService service;
	
	@PostMapping
	public ResponseEntity<ResponseStructure<StudentResponse>> saveStudent(@RequestBody StudentRequest student)
	{
		return service.saveData(student);
		
		
	}
	@PutMapping("/{studentId}")
	public ResponseEntity<ResponseStructure<StudentResponse>> updateStudent(@RequestBody StudentRequest student, @PathVariable int studentId)
	{
			return service.updateData(student, studentId);
	}
	
	@DeleteMapping("/{studentId}")
	public ResponseEntity<ResponseStructure<StudentResponse>> deleteStudent(@PathVariable int studentId)
	{
		return service.deleteData(studentId);
	}
	@GetMapping("/{studentId}")
	public ResponseEntity<ResponseStructure<StudentResponse>> findStudent(@PathVariable int studentId)
	{
		return service.findData(studentId);
	}
	
	@GetMapping
	@CrossOrigin
	public ResponseEntity<ResponseStructure<List<StudentResponse>>> findAllStudent()
	{
		return service.findAllData();
	}
	
	@GetMapping(params = "email")
	public ResponseEntity<ResponseStructure<StudentResponse>> findByEmail(@RequestParam String email)
	{
		return service.findByEmail(email);
	}
	
	@GetMapping(params = "grade")
	public ResponseEntity<ResponseStructure<List<String>>>  findEmailByGrade(@RequestParam String grade)
	{
		return service.findEmailByGrade(grade);
	}
	
}
