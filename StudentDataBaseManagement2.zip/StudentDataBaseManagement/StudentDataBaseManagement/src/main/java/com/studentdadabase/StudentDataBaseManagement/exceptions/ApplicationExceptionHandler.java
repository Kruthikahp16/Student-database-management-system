package com.studentdadabase.StudentDataBaseManagement.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.studnetdatabase.StudentDataBaseManagement.utilll.ErrorStructure;

@RestControllerAdvice
public class ApplicationExceptionHandler {
	
	@ExceptionHandler
	public ResponseEntity<ErrorStructure> studentNotFoundByid(StudentNotFoundByIdException e)
	{
		ErrorStructure structure = new ErrorStructure();
		structure.setMessage(e.getMessage());
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		structure.setRootCause("The Student is Not present with the Requested Id ..!!");
		
		
		return new ResponseEntity<ErrorStructure>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler
	public ResponseEntity<ErrorStructure> emailnotFoundByGrade(NoEmailFouundOnThisGrade e)
	{
		ErrorStructure structure = new ErrorStructure();
		structure .setMessage(e.getMessage());
		structure.setRootCause("No email Fouund on this Grade");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		
		return new ResponseEntity<ErrorStructure>(structure,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler
	 public ResponseEntity<ErrorStructure> StudentNotFoundByEmail(StudentNotFoundByEmail e)
	 {
		ErrorStructure structure = new ErrorStructure();
		structure.setMessage(e.getMessage());
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		structure.setRootCause("Cannot find the Student by this Email");
		
		return new ResponseEntity<ErrorStructure>(structure,HttpStatus.NOT_FOUND);
		 
		 
	 }
}
