package com.studentdadabase.StudentDataBaseManagement.dto;

public class StudentRequest {
	
	private String studentGrade;
	private String studentName;
	private String studentEmail;
	private String studentPhno;
	public String getStudentGrade() {
		return studentGrade;
	}
	public void setStudentGrade(String studentGrade) {
		this.studentGrade = studentGrade;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentEmail() {
		return studentEmail;
	}
	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}
	public String getStudentPhno() {
		return studentPhno;
	}
	public void setStudentPhno(String studentPhno) {
		this.studentPhno = studentPhno;
	}
	
	
}
