package com.studentdadabase.StudentDataBaseManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentDataBaseManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
